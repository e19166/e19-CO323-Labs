#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define PORT 32000
#define MAX_BUFFER_SIZE 100

int main() {
    int sockfd, n;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Set socket option to enable address reuse
    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // Bind socket to server address
    bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

    printf("Time Server started. Listening on port %d\n", PORT);

    while (1) {
        // Receive the initial message from the client
        len = sizeof(cliaddr);
        n = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&cliaddr, &len);

        // Null-terminate the received message
        buffer[n] = '\0';

        // Print the received message
        printf("Received message from client: %s\n", buffer);

        // Get current time
        time_t t;
        struct tm* tm_info;
        time(&t);
        tm_info = localtime(&t);

        // Format time as a string
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);

        // Send the time to the client
        sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&cliaddr, len);

        // Sleep for one second before sending the next time update
        sleep(1);
    }

    // Close the socket (this code will not be reached in the current loop implementation)
    close(sockfd);

    return 0;
}
