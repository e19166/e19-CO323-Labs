#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>

#define PORT 32000
#define MAX_BUFFER_SIZE 1000

int main() {
    int sockfd, n;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Bind socket to server address
    bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

    printf("UDP Echo Server started. Listening on port %d\n", PORT);

    while (1) {
        len = sizeof(cliaddr);

        // Receive message from client
        n = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&cliaddr, &len);

        // Send the received message back to the client
        sendto(sockfd, buffer, n, 0, (struct sockaddr*)&cliaddr, sizeof(cliaddr));

        // Null-terminate the received message to print it
        buffer[n] = '\0';

        // Print the received message
        printf("Received: %s\n", buffer);
    }

    // Close the socket (this code will not be reached in the current loop implementation)
    close(sockfd);

    return 0;
}
