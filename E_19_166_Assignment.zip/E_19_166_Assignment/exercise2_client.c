#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 32000
#define FILENAME "clientfile.txt"
#define BUFFER_SIZE 1000

int main() {
    int sockfd, n;
    struct sockaddr_in servaddr;
    FILE *file;
    char buffer[BUFFER_SIZE];

    // Create socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address structure
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Use the server's IP address
    servaddr.sin_port = htons(PORT);

    // Connect to the server
    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    // Receive file size from the server
    long file_size;
    if (recv(sockfd, &file_size, sizeof(file_size), 0) <= 0) {
        perror("Error receiving file size");
        exit(EXIT_FAILURE);
    }

    // Open the file to be written
    if ((file = fopen(FILENAME, "wb")) == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Receive and write the file in chunks
    while (file_size > 0) {
        n = recv(sockfd, buffer, sizeof(buffer), 0);
        if (n <= 0) {
            perror("Error receiving file");
            break;
        }
        fwrite(buffer, 1, n, file);
        file_size -= n;
    }

    // Close the file and socket
    fclose(file);
    close(sockfd);

    printf("File received successfully.\n");

    return 0;
}
