/* Sample UDP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    int sockfd, n;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char mesg[1000];

    char* banner = "Hello UDP client! This is UDP server";

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(32000);

    // Bind the socket to the server address
    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("Error binding socket");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Server waiting for messages. Press Ctrl+C to terminate.\n");

    while (1) {
        // Receive a message from a client
        len = sizeof(cliaddr);
        n = recvfrom(sockfd, mesg, sizeof(mesg), 0, (struct sockaddr*)&cliaddr, &len);

        if (n < 0) {
            perror("Error receiving message");
            continue;  // Continue to the next iteration of the loop
        }

        // Send a reply back to the client
        sendto(sockfd, banner, n, 0, (struct sockaddr*)&cliaddr, sizeof(cliaddr));

        // Display the received message
        mesg[n] = '\0';
        printf("Received: %s\n", mesg);
    }

    // Close the socket (this code will not be reached in the current loop implementation)
    close(sockfd);

    return 0;
}
