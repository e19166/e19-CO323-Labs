#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 32000
#define MAX_BUFFER_SIZE 1000

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("usage: %s <server IP address>\n", argv[0]);
        return -1;
    }

    int sockfd, n, numSentences;
    struct sockaddr_in servaddr;
    socklen_t len;
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(PORT);

    // Get the number of sentences from the user
    printf("Enter the number of sentences: ");
    scanf("%d", &numSentences);

    // Send the number of sentences to the server
    sendto(sockfd, &numSentences, sizeof(int), 0, (struct sockaddr*)&servaddr, sizeof(servaddr));

    // Receive acknowledgment 'ack' from the server
    n = recvfrom(sockfd, buffer, sizeof(buffer), 0, NULL, NULL);

    for (int i = 0; i < numSentences; i++) {
        // Get sentence from the user
        printf("Enter sentence %d: ", i + 1);
        scanf(" %[^\n]", buffer);

        // Send sentence to the server
        sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&servaddr, sizeof(servaddr));

        // Receive the capitalized sentence from the server
        n = recvfrom(sockfd, buffer, sizeof(buffer), 0, NULL, NULL);

        // Null-terminate the received sentence to print it
        buffer[n] = '\0';

        // Print the capitalized sentence received from the server
        printf("Received from server: %s\n", buffer);
    }

    // Close the socket
    close(sockfd);

    return 0;
}
