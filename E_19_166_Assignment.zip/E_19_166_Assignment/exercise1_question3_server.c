#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PORT 32000
#define MAX_BUFFER_SIZE 1000

void capitalizeSentence(char* sentence) {
    int i = 0;
    while (sentence[i]) {
        sentence[i] = toupper((unsigned char)sentence[i]);
        i++;
    }
}

int main() {
    int sockfd, n, numSentences;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Bind socket to server address
    bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

    printf("CSP Capitalizer Server started. Listening on port %d\n", PORT);

    // Receive the number of sentences from the client
    len = sizeof(cliaddr);
    n = recvfrom(sockfd, &numSentences, sizeof(int), 0, (struct sockaddr*)&cliaddr, &len);

    // Send acknowledgment 'ack' back to the client
    sendto(sockfd, "ack", 3, 0, (struct sockaddr*)&cliaddr, sizeof(cliaddr));

    for (int i = 0; i < numSentences; i++) {
        // Receive sentence from the client
        n = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&cliaddr, &len);

        // Capitalize the sentence
        capitalizeSentence(buffer);

        // Send the capitalized sentence back to the client
        sendto(sockfd, buffer, n, 0, (struct sockaddr*)&cliaddr, sizeof(cliaddr));

        // Null-terminate the capitalized sentence to print it
        buffer[n] = '\0';

        // Print the received and capitalized sentence
        printf("Received and Capitalized: %s\n", buffer);
    }

    // Close the socket
    close(sockfd);

    return 0;
}
