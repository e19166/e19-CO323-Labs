#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define PORT 32000
#define MAX_BUFFER_SIZE 100

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("usage: %s <server IP address>\n", argv[0]);
        return -1;
    }

    int sockfd, n;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // Set up server address structure
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(PORT);

    // Set up client address structure
    bzero(&cliaddr, sizeof(cliaddr));
    cliaddr.sin_family = AF_INET;
    cliaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    cliaddr.sin_port = htons(0);  // Let the system assign a random port

    // Bind socket to client address
    bind(sockfd, (struct sockaddr*)&cliaddr, sizeof(cliaddr));

    while (1) {
        // Send an initial message to the server
        printf("Sending initial message to the server...\n");
        sendto(sockfd, "Requesting Time", strlen("Requesting Time"), 0, (struct sockaddr*)&servaddr, sizeof(servaddr));
        printf("Initial message sent to the server\n");

        // Receive time updates continuously
        len = sizeof(servaddr);
        n = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&servaddr, &len);

        // Null-terminate the received time to print it
        buffer[n] = '\0';

        // Print the received time
        printf("Received time from server: %s\n", buffer);

        // Sleep for one second before requesting the time again
        sleep(1);
    }

    // Close the socket (this code will not be reached in the current loop implementation)
    close(sockfd);

    return 0;
}
