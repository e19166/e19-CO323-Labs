#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 32000
#define FILENAME "serverfile.txt"
#define BUFFER_SIZE 1000

int main() {
    int listenfd, connfd, n;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t clilen;
    FILE *file;
    char buffer[BUFFER_SIZE];

    // Create socket
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address structure
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Bind socket
    if (bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(listenfd, 5) == -1) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("TCP File Transfer Server started. Listening on port %d\n", PORT);

    // Accept connection from client
    clilen = sizeof(cliaddr);
    if ((connfd = accept(listenfd, (struct sockaddr*)&cliaddr, &clilen)) == -1) {
        perror("Accept failed");
        exit(EXIT_FAILURE);
    }

    // Open the file to be sent
    if ((file = fopen(FILENAME, "rb")) == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Get the file size
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Send file size to client
    send(connfd, &file_size, sizeof(file_size), 0);

    // Send the file in chunks
    while ((n = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        send(connfd, buffer, n, 0);
        printf("Sent %d bytes\n", n);
    }

    // Close the file and socket
    fclose(file);
    close(connfd);
    close(listenfd);

    printf("File sent successfully.\n");

    return 0;
}
